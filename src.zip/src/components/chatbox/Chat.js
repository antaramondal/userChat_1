import React ,{useState}from 'react';



function Chat() {
    const [chatList,setChatList]=useState(true);
    const [chatListBox,setChatListBox]= useState(false);
    
    return (
        <div>
            
        </div>
    )
}

export default Chat
