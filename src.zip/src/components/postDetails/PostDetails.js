import React from 'react'
import Header from '../header/Header';

function PostDetails() {
    return (
        <div className="body-div">
            <Header headerName="Posts"/>
            <div className="empty-body">Coming Soon </div>
            
        </div>
    )
}

export default PostDetails
