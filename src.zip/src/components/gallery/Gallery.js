import React from 'react';
import Header from '../header/Header';

function Gallery() {
    return (
        <div className="body-div">
            <Header headerName="Gallery"/>
            <div className="empty-body">Coming Soon </div>
            
        </div>
    )
}

export default Gallery
