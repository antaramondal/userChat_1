import React, { useEffect, useReducer, useContext } from "react";
import { UserContext } from "../../App";
import ChatList from "../chatbox/ChatList";
import ChatListBox from "../chatbox/ChatListBox";
import Gallery from "../gallery/Gallery";
import PostDetails from "../postDetails/PostDetails";
import Profile from "../profile/Profile";
import SideNav from "../sideNav/SideNav";
import ToDo from "../todo/ToDo";

const handler = {
  profile: true,
  posts: false,
  gallery: false,
  todo: false,
};

const reducer = (state, action) => {
  switch (action.type) {
    case "profile":
      return { profile: true, posts: false, gallery: false, todo: false };
    case "posts":
      return {
        profile: false,
        posts: true,
        gallery: false,
        todo: false,
      };
    case "gallery":
      return { profile: false, posts: false, gallery: true, todo: false };
    case "todo":
      return {
        profile: false,
        posts: false,
        gallery: false,
        todo: true,
      };
    default:
      return state;
  }
};

export const HandlerContext = React.createContext();

function DashBoard() {
  const userContext = useContext(UserContext);
  const [handlerState, dispatchHnadler] = useReducer(reducer, handler);

  useEffect(() => {
    return () => {
      userContext.usedispatch({ type: "signOutUser" });
    };
  }, []);
  return (
    <HandlerContext.Provider
      value={{ usehandler: handlerState, handlerdispatch: dispatchHnadler }}
    >
      <div className="main-body">
        <SideNav />
        {handlerState.profile ? <Profile /> : null}
        {handlerState.posts ? <PostDetails /> : null}
        {handlerState.gallery ? <Gallery /> : null}
        {handlerState.todo ? <ToDo /> : null}
        <ChatList heading="Chats">
            <ChatListBox/>

        
        </ChatList>
        
      </div>
    </HandlerContext.Provider>
  );
}

export default DashBoard;
