import React from "react";
import Header from "../header/Header";

function ToDo() {
  return (
    <div className="body-div">
      <Header headerName="ToDo"/>
      <div className="empty-body">Coming Soon </div>
    </div>
  );
}

export default ToDo;
